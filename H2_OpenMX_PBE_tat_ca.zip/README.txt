Phep tinh H2 voi OpenMX 3.9, GGA-PBE, H-H = 0.74 angstrom.
Nang luong Utot = -1.163792535108 Hartree. SCF hoi tu.
H2.dat la dau vao; H2.out la ket qua; H2.log la nhat ky; H2_rst la du lieu restart; cac file .cube la du lieu luoi.
Duong dan DATA.PATH trong H2.dat la duong dan cua may da chay; thay bang duong dan DFT_DATA19 cua ban khi chay o may khac.
Goi nay gom tat ca file cua phep tinh, khong gom chuong trinh OpenMX va bo du lieu DFT_DATA19.
